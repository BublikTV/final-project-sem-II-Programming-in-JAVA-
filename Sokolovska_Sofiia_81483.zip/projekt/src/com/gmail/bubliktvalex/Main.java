package com.gmail.bubliktvalex;

public class Main {
    public static void main(String[] args) {
// TODO Auto-generated method stub
        Client client = new Client();
        client.start();
        ChatServer chatServer = new ChatServer();
        chatServer.serverStart();
    }
}

