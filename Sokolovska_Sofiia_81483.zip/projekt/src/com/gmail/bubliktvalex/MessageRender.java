package com.gmail.bubliktvalex;

public interface MessageRender {
    public void renderMessage(Message message);
}

